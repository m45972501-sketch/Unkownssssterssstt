# RazenBot
Node.js v24 + discord.js v14. متعدد السيرفرات وبدون Database.

## Termux
pkg update && pkg upgrade
pkg install nodejs
cd RazenBot
npm install
npm start

عدّل config.js وضع token و clientId.
فعّل من Developer Portal:
- Server Members Intent
- Message Content Intent
- Presence Intent

التذاكر تبدأ من 0 وتُحفظ في settings.json.
الـApply يمكن تشغيله/إيقافه من config.js: apply.enabled
